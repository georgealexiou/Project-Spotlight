package com.example.onomatest2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.io.Console;

public class Activity2 extends AppCompatActivity {

    ImageView canvasImg;
    LinearLayout layer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int[] wh = (int[]) getIntent().getExtras().get("pixelR");
        int w = wh[0];
        int h = wh[1];

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        canvasImg = findViewById(R.id.canvasImg);
        layer = findViewById(R.id.layout);


        ViewGroup.LayoutParams canvasLayout = (FrameLayout.LayoutParams)canvasImg.getLayoutParams();

        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);

        int w2 = Math.round (size.y * w / h);
        canvasImg.setLayoutParams (new FrameLayout.LayoutParams(  w2 , canvasLayout.height, Gravity.RIGHT|Gravity.BOTTOM));

//        canvasImg.onDragEvent(new View.OnDragListener(){
//            @Override
//            public boolean onDrag(View v, DragEvent event) {
//                int action = event.getAction();
//                switch (event.getAction()) {
//                    case DragEvent.ACTION_DRAG_STARTED:
//                        skata();
//                        break;
//                    case DragEvent.ACTION_DRAG_ENTERED:
//                        skata();
//                        break;
//                    case DragEvent.ACTION_DRAG_EXITED:
//                        skata();
//                        break;
//                    case DragEvent.ACTION_DROP:
//                        skata();
//                        break;
//                    case DragEvent.ACTION_DRAG_ENDED:
//                        //asd
//                        break;
//                }
//                return true;
//            }
//        });

        canvasImg.setOnTouchListener(new View.OnTouchListener() {
            int i=0;
            public boolean onTouch(View v, MotionEvent event) {
                Log.d("aa"," " +event.getAction()     );
                i++;
                Log.d("aaa","i");
                Bitmap imageBitmap = Bitmap.createBitmap(canvasImg.getWidth(),canvasImg.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(imageBitmap);
                float scale = getResources().getDisplayMetrics().density;
                Paint p = new Paint();
                Paint p2 = new Paint();
                Paint p3 = new Paint();
                p3.setColor(Color.RED);
                p2.setColor(Color.rgb(150,150,150));
                p.setColor(Color.BLUE);
                p.setStrokeWidth(p.getStrokeWidth()+6);

                canvas.drawRect(0,0,canvasImg.getWidth(),canvasImg.getHeight(),p2);
                canvas.drawLine(canvasImg.getWidth()/3,0,canvasImg.getWidth()/3 ,canvasImg.getHeight(),p);
                canvas.drawLine(2 * canvasImg.getWidth()/3,0,2 * canvasImg.getWidth()/3 ,canvasImg.getHeight(),p);

                canvas.drawLine(0,canvasImg.getHeight()/3,canvasImg.getWidth(),canvasImg.getHeight()/3,p);
                canvas.drawLine(0,2 * canvasImg.getHeight()/3,2 * canvasImg.getWidth(),2 * canvasImg.getHeight()/3,p);

                canvas.drawCircle(event.getX(),event.getY(),20,p3);
                Log.d("aaa",event.getX() + " " + event.getY());
                canvasImg.setImageBitmap(imageBitmap);
                return false;
            }});
    }

//    protected void skata(){
//        Log.d("aa"," " +event.getAction()     );
//        i++;
//        Log.d("aaa","i");
//        Bitmap imageBitmap = Bitmap.createBitmap(canvasImg.getWidth(),canvasImg.getHeight(), Bitmap.Config.ARGB_8888);
//        Canvas canvas = new Canvas(imageBitmap);
//        float scale = getResources().getDisplayMetrics().density;
//        Paint p = new Paint();
//        p.setColor(Color.BLUE);
//        p.setStrokeWidth(p.getStrokeWidth()+6);
//
//        canvas.drawLine(canvasImg.getWidth()/3,0,canvasImg.getWidth()/3 ,canvasImg.getHeight(),p);
//        canvas.drawLine(2 * canvasImg.getWidth()/3,0,2 * canvasImg.getWidth()/3 ,canvasImg.getHeight(),p);
//
//        canvas.drawLine(0,canvasImg.getHeight()/3,canvasImg.getWidth(),canvasImg.getHeight()/3,p);
//        canvas.drawLine(0,2 * canvasImg.getHeight()/3,2 * canvasImg.getWidth(),2 * canvasImg.getHeight()/3,p);
//
//        canvas.drawCircle(event.getX(),event.getY(),20,p);
//        Log.d("aaa",event.getX() + " " + event.getY());
//        canvasImg.setImageBitmap(imageBitmap);
//    }
}




